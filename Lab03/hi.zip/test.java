package hust.soict.dsai.garbage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class NoGarbage {

	public static void main(String[] args) throws IOException {
		String filename = "C:\\Users\\JULLER\\IT3103.732873.2023.1.5054.Hoan.LV\\lab03\\OtherProjects\\src\\hust\\soict\\dsai\\garbage\\test.txt";
		byte[] inputBytes = { 0 };
		long startTime, endTime;
		inputBytes = Files.readAllBytes(Paths.get(filename));
		startTime = System.currentTimeMillis();
		StringBuilder outputStringBuilder = new StringBuilder();
		for (byte b : inputBytes) {
			outputStringBuilder.append((char) b);
		}
		endTime = System.currentTimeMillis();
		System.out.println(endTime - startTime);
	}

}

package hust.soict.dsai.garbage;
import java.util.Random;
// Lưu Việt Hoàn - 20215054
public class ConcatenationInLoops {
    public static void main(String[] args) {
        // Tạo một đối tượng Random với seed là 123
        Random r = new Random(123);
        // Đo thời gian bắt đầu
        long start = System.currentTimeMillis();
        // Sử dụng chuỗi thông thường với toán tử += trong vòng lặp
        String s = "";
        for (int i = 0; i < 65536; i++) 
            s += r.nextInt(2);
        // In ra thời gian thực hiện và kết quả
        System.out.println("Thời gian sử dụng chuỗi: " + (System.currentTimeMillis() - start));

        // Reset lại đối tượng Random với seed là 123
        r = new Random(123);
        // Đo thời gian bắt đầu
        start = System.currentTimeMillis();
        // Sử dụng StringBuilder để tối ưu hóa trong vòng lặp
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 65536; i++)
            sb.append(r.nextInt(2));
        s = sb.toString();
        // In ra thời gian thực hiện và kết quả
        System.out.println("Thời gian sử dụng StringBuilder: " + (System.currentTimeMillis() - start));
    }
}

public class GarbageCreator {
	public static void main(String[] args) throws IOException {
		String filename = "C:\\Users\\JULLER\\IT3103.732873.2023.1.5054.Hoan.LV\\lab03\\OtherProjects\\src\\hust\\soict\\dsai\\garbage\\tes.txt";
		byte[] inputBytes = { 0 };
		long startTime, endTime;
		inputBytes = Files.readAllBytes(Paths.get(filename));
		startTime = System.currentTimeMillis();
		String outputString = "";
		for (byte b : inputBytes) {
			outputString += (char) b;
		}
		endTime = System.currentTimeMillis();
		System.out.println(endTime - startTime);
	}
}