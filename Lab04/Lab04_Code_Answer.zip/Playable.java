package hust.soict.dsai.aims.media;
// Lưu Việt Hoàn - 20215054
public interface Playable {

	public static void play() {
		
	}
}
