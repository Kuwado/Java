package hust.soict.dsai.aims.media;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class TestPassingParameter {

	public static void print(List<Media> madie) {
		for (int i = 0; i < madie.size(); i++) {
			System.out.println(madie.get(i).toString());
		}
	}
	
	public static void main(String[] args) {

				
				

				
				
				
	}
}