// Luu Viet Hoan
// 20215054
package hust.soict.dsai.aims.cart;
import hust.soict.dsai.aims.media.Media;

import java.util.ArrayList;

public class Cart {
	public static final int MAX_NUMBERS_ORDERED = 20; // so luong dia toi da trong mot gio hang
	private ArrayList<Media> itemsOrdered = new ArrayList<Media>();
	
	// ham tinh tong tien
	public float totalCost() {
		float total = 0.0f;
		for (int i = 0; i < itemsOrdered.size(); i++) {
			total += itemsOrdered.get(i).getCost(); // cong lan luot
		}
		return total;
	}


	// Ham them Media
	public void addMedia(Media med) {
		boolean ans = true;
		for (int i = 0; i < itemsOrdered.size(); i++) { // kiem tra xem media da ton tai chua
			if (med.equals(itemsOrdered.get(i))) {
				System.out.println("Media da ton tai");
				ans = false;
				break;
			}
		}
		if (ans) { // neu chua thi them
			itemsOrdered.add(med);
			System.out.println("Media da duoc them vao");
		}
	}
	
	// ham xoa san pham trong cart
	public void removeMedia(Media med) {
		boolean ans = false;
		for (int i = 0; i < itemsOrdered.size(); i++) { // kiem tra media co ton tai hay khong
			if (med.equals(itemsOrdered.get(i))) { // neu co thi xoa
				itemsOrdered.remove(i);
				System.out.println("Media da duoc xoa");
				ans = true;
				break;
			}
		}
		if (!ans) { // khong co bao khong thay
			System.out.println("Khong tim thay Media nay");
		}
	}

	// Ham in danh sach san pham trong cart
	public void printList() {
		for (int i = 0; i < itemsOrdered.size(); i++) {
			System.out.println((i+1) + ". " + itemsOrdered.get(i).toString());
		}
	}
	
	

	// Ham tim kiem theo ID - LVHoan - 20215054
		public void searchbyID(int idsearch) {
		    boolean found = false; // bien kiem tra xem co tim thay hay khong
		    for (int i = 0; i < itemsOrdered.size(); i++) {
		        if (idsearch == itemsOrdered.get(i).getId()) {
		            System.out.println(itemsOrdered.get(i).toString());
		            found = true; // da tim thay
		            break; // dung vong lap ngay khi thay
		        }
		    }

		    // In ra thong bao neu khong thay
		    if (!found) {
		        System.out.println("DVD với ID " + idsearch + " khong ton tai trong gio hang.");
		    }
		}

		// Ham tim kiem theo tieu de - Viet Hoan - 20215054
		public void searchbyTitle(String titlesearch) {
			boolean found = false; // bien kiem tra xem co tim thay hay khong
			for (int i = 0; i < itemsOrdered.size(); i++) {
				if( itemsOrdered.get(i).getTitle().equals(titlesearch) ) {
					System.out.println(itemsOrdered.get(i).toString());
					found = true; // da tim thay'
					break; // dung vong lap
				}
			}
				if(!found) // neu khong tim thay
					System.out.println("DVD voi tieu de " + titlesearch + " khong ton tai trong gio hang.");
		}


}