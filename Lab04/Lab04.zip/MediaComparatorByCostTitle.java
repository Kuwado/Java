package hust.soict.dsai.aims.media;
import java.util.Comparator;
// Lưu Việt Hoàn - 20215054
public class MediaComparatorByCostTitle implements Comparator<Media> {
		
		@Override
		public int compare(Media med1, Media med2) {
			int CostCom = Float.compare(med1.getCost(), med2.getCost()); // so sanh cost
			
			return (CostCom != 0 ) ? CostCom : med1.getTitle().compareTo(med2.getTitle()); //neu cost giong nhau so sanh title
	}

}
