package hust.soict.dsai.aims.media;

import java.util.Comparator;
// Luu Viet Hoan - 20215054
public abstract class Media {
	protected int id;
	public String title;
	public String category;
	protected float cost;
	
	
	// getter
	public String getTitle() {
		return title;
	}
	public String getCategory() {
		return category;
	}
	public float getCost() {
		return cost;
	}
	public int getId() {
        return id;
    }
	
	//setter
	public void setTitle(String title) {
		this.title = title;
	}

	public Media() {
		// TODO Auto-generated constructor stub
	}
	
	@Override
    public boolean equals(Object obj) { // viet lai ham equals
        if (this == obj) {
            return true;
        }

        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }

        Media other = (Media) obj; // media
        return title.equals(other.title);
    }
	
	public static final Comparator<Media> COMPARE_BY_COST_TITLE = new MediaComparatorByCostTitle();
	public static final Comparator<Media> COMPARE_BY_TITLE_COST = new MediaComparatorByTitleCost();

	
	
	
}
