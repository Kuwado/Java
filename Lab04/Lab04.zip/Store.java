package hust.soict.dsai.aims.store;
import java.util.ArrayList;
// Luu Viet Hoan - 20215054
import hust.soict.dsai.aims.media.Media;

public class Store {
	public static final int MAX = 999999; // so luong dvd toi da cua cua hang
	private ArrayList<Media> itemsInStore = new ArrayList<Media>();	
	
	// ham tim san pham theo title
	public Media FindByTitleStore(String Stitle) {
		Media med = null; // neu khong co tra ve null
		for ( int i = 0; i < itemsInStore.size(); i++) {
			if (Stitle.equals(itemsInStore.get(i).getTitle())) {// neu thay title
				med = itemsInStore.get(i); // tra ve media
				break;
			}
		}
		return med;
	}
	
	// Ham them san pham
		public void addMedia(Media med) {
			boolean ans = true;
			for (int i = 0; i < itemsInStore.size(); i++) {// kiem tra media da ton tai chua
				if (med.equals(itemsInStore.get(i))) {
					System.out.println("San pham da ton tai");// neu da co thi bao loi
					ans = false;
					break;
				}
			}
			if (ans) {
				itemsInStore.add(med);// chua co thi them
				System.out.println("San pham da duoc them vao");
			}
		}
		
		// ham xoa san pham
		public void removeMedia(Media med) {
			boolean ans = false;
			for (int i = 0; i < itemsInStore.size(); i++) { // neu tim thay
				if (med.equals(itemsInStore.get(i))) {
					itemsInStore.remove(i); // thuc hien xoa
					System.out.println("San pham da duoc xoa");
					ans = true;
					break;
				}
			}
			if (!ans ) {// neu khong thay bao loi
				System.out.println("Khong tim thay san pham nay");
			}
		}
	
	// in danh sach san pham
	public void printlist() {
		for (int i = 0; i < itemsInStore.size(); i++) {
			System.out.println((i+1) + ". " + itemsInStore.get(i).toString());
		}
	}
}

