package hust.soict.dsai.aims.media;

public class Disc extends Media{
	protected String director;
	protected int length;
	
	// getter
	public String getDirector() {
		return director;
	}


	public int getLength() {
		return length;
	}

	//Con
	public Disc() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Disc(String director, int length) {
		super();
		this.director = director;
		this.length = length;
	}


	public Disc(int length) {
		super();
		this.length = length;
	}
	
	
	
	
		

}
