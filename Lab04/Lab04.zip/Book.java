package hust.soict.dsai.aims.media;
import java.util.ArrayList;
import java.util.List;
// Luu Viet Hoan - 20215054
public class Book extends Media {
	private List<String> authors = new ArrayList<String>();

	public List<String> getAuthors() {
		return authors;
	}

	public Book() {
		super();
	}
	
	public Book(String title, String category, float cost ) {
		super();
		this.title = title;
		this.category = category;
		this.cost = cost;
	}
	

	public Book(int id, String title, String category, float cost, List<String> authors) {
		super();
		this.id = id;
		this.title = title;
		this.category = category;
		this.cost = cost;
		this.authors = authors;
	}
	
	public void addAuthor(String name) {
		boolean check = true;
		for (int i = 0; i < authors.size(); i++) {
			if (authors.get(i).equals(name)) {
				System.out.println("Tac gia nay da ton tai");
				check = false;
				break;
			}
		}
		if (check){
			authors.add(name);
			System.out.println("Tac gia da duoc them");
		}
	}
	
	public void removeAuthor(String name) {
		boolean check = false;
		for (int i = 0; i < authors.size(); i++) {
			if (authors.get(i).equals(name)) {
				authors.remove(i);
				System.out.println("Da xoa tac gia nay");
				check = true;
				break;
			}
		}
		if (!check) {
			System.out.println("Tac gia nay khong ton tai");
		}
	}
	
	public void showAuthor() {
		System.out.print("Danh sach tac gia: ");
		for (String name : authors) {
			System.out.print("\t" + name);
		}
		System.out.println();
	}
	
	@Override
	public String toString() {
		return "DVD - " + getTitle() + " - " + getCategory() + " - " + getCost() + " $ - " ;
	}

}
