package hust.soict.dsai.aims.media;
import hust.soict.dsai.aims.cart.Cart;

public class CartTest {
	public static void main(String[] args) {
		Cart cart = new Cart();

		// tao dia moi va them vao gio hang
		DigitalVideoDisc dvd1 = new DigitalVideoDisc("The Lion King", "Animation", "Roger Allers", 87, 19.95f);
		Media med = dvd1;
		cart.addMedia(med);

		DigitalVideoDisc dvd2 = new DigitalVideoDisc("Star Wars", "Science Fiction", "George Lucas", 87, 24.95f);
		cart.addMedia(dvd2);

		DigitalVideoDisc dvd3 = new DigitalVideoDisc("Aladin", "Animation", 18.99f);
		cart.addMedia(dvd3);


	}

}