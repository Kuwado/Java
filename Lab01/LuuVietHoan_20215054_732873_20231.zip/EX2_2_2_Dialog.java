package lab01;
// Luu Viet Hoan
// 20215054
import javax.swing.JOptionPane;

public class EX2_2_2_Dialog {
		public static void main(String[] args) {
			JOptionPane.showMessageDialog(null, "Hello world! How are you?"); // hien thi hop thoai
			System.exit(0);
		}
	}
