package lab01;
// Luu Viet Hoan 
// 20215054
public class EX2_2_1_HelloWorld {
	public static void main(String arg[]) {
		System.out.println("Xin chao \n cac ban!"); // in ra man hinh 
		System.out.println("Hello \n World!");
	}
}
